package com.webagesolutions.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.webagesolutions.users.User;
import com.webagesolutions.users.UserAddException;
import com.webagesolutions.users.UserStore;

public class InMemoryUserStore implements UserStore {

	private Map<String, User> index = new HashMap<String, User>();
	
	private List<User> userList=new ArrayList<User>();

	
	public User getUser(String email) {
		return index.get(email);
	}

	public Iterable<User> listAllUsers() {
		return Collections.unmodifiableList(userList);
	}

	public void putUser(User user, String verifyPassword)
			throws UserAddException {
		if (verifyPassword.equals(user.getPassword())) {
			userList.add(user);
		} else {
			throw new UserAddException("Password incorrect.");
		}
		if (index.containsKey(user.getEmail())) {
			userList.remove(getUser(user.getEmail()));
		}
		index.put(user.getEmail(), user);
	}

	
}
