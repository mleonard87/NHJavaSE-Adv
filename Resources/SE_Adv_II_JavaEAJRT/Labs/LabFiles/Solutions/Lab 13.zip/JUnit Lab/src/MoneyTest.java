import junit.framework.TestCase;


public class MoneyTest extends TestCase {

	public void testToString() {
		assertEquals("CAD 7.32", new Money(7, 32, "CAD").toString());
	}

	public void testToString_SingleDigitCents() {
		assertEquals("CAD 7.02", new Money(7, 2, "CAD").toString());
	}

	public void testEquals_Null() {
		final Money money = new Money(100, 0, "CAD");
		assertTrue(!money.equals(null));
	}

	public void testCompareTo_DifferentCurrencies() {
		final Money canadian = new Money(100, 0, "CAD");
		final Money american = new Money(90, 0, "USD");
		try {
			canadian.compareTo(american);
			fail("Should not be able to compare CAD with USD");
		}
		catch (final IllegalArgumentException success) {
			assertEquals("Cannot compare CAD with USD.",
			success.getMessage());
		}
	}


}
