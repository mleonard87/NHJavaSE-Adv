
public class Money implements Comparable {
      long dollars;
      long cents;
      String currencySymbol;
 
      Money(long dollars, long cents, String currencySymbol) {
            this.dollars = dollars;
            this.cents = cents;
            this.currencySymbol = currencySymbol;
      }
      public int compareTo(final Object other) {
            final Money that = (Money) other;
            if (this.currencySymbol.equals(that.currencySymbol) == false) {
        		throw new IllegalArgumentException(
        		"Cannot compare " + this.currencySymbol + " with " + 
        		that.currencySymbol + ".");
        	}
            final long difference =
                  (this.dollars * 100 + this.cents)
                        - (that.dollars * 100 + that.cents);
            if (difference < 0) {
                  return -1;
            } else if (difference > 0) {
                  return 1;
            } else {
                  return 0;
            }
      }
 
      public boolean equals(final Object other) {
            if (other != null && other instanceof Money) {
                  final Money that = (Money) other;
                  return (this.compareTo(that) == 0);
            } else {
                  return false;
            }
 
      }
 
      public String toString() {
    		final String centsAsString;
    		if (cents < 10) {
    			centsAsString = "0" + cents;
    		}
    		else {
    			centsAsString = String.valueOf(cents);
    		}
    		return currencySymbol + " " + dollars + "." + centsAsString;
    	}

}

