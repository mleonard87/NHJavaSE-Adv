package com.webagesolutions.synch;

public class SharedBean {
	
	int value;

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		if (value != this.value +1) {
			System.out.printf("Bad increment: current=%d new=%d\n",
					this.value, value);
		}
		this.value = value;
	} 


}
