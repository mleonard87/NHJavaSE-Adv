package com.webagesolutions.socks;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class ResponderHandler implements Runnable {
	Socket socket = null;

	ResponderHandler(Socket s) {
		socket = s;
	}

	public void run() {
		Scanner inputScanner = null;
		PrintWriter output = null;
		String inputLine = "";
		try {
			System.out.println("Opening inputs/outputs");
			// Create an input scanner.
			inputScanner = new Scanner(socket.getInputStream());
			// Create a PrintWriter
			output = new PrintWriter(socket.getOutputStream());
			do {
				/*
				 * Read a line then send it back upper-case.
				 */
				inputLine = inputScanner.nextLine();
				System.out.printf("Input was '%s'\n", inputLine);
				output.println(inputLine.toUpperCase());
				output.flush();
			} while (!"bye".equals(inputLine));
			socket.close();
		} catch (IOException e) {
			e.printStackTrace();
			try {
				socket.close();
			} catch (Exception ex) {
			}
		}
	}
}
