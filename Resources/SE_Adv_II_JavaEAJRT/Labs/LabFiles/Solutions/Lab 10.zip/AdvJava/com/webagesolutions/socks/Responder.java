package com.webagesolutions.socks;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class Responder {
	public static void main(String[] args) {
		ServerSocket serverSocket = null;
		Executor threadPool = null;

		try {
			threadPool = Executors.newCachedThreadPool();
			serverSocket = new ServerSocket(10001);
			while (true) {
				Socket s = serverSocket.accept();
				System.out.printf("Got a connection from %s\n", s.getRemoteSocketAddress());

				ResponderHandler handler = new ResponderHandler(s);
				threadPool.execute(handler);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
