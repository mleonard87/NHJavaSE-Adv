package com.webagesolutions.reflection;

public class Target {
	public void sayHello() {
		System.out.println("Hello");
	}
	
	public void sayGoodbye() {
		System.out.println("Goodbye");
	}
	
}
