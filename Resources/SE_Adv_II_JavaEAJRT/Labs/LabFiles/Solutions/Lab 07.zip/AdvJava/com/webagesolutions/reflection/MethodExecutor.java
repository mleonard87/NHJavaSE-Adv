package com.webagesolutions.reflection;

import java.lang.reflect.Method;
import java.util.Scanner;

public class MethodExecutor {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.printf("Enter a fully qualified class name:\n");
		String className = in.nextLine();

		Class clazz = null; 

		try {
			clazz = Class.forName(className);
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
			System.exit(1);
		} 
		Object instance=null;
		try {
			instance = clazz.newInstance();
		} catch (Throwable e1) {
			e1.printStackTrace();
			System.exit(1);
		} 
		while (true) {
			System.out.println("Enter a method name to invoke, or '-' to exit:");
			String methodName = in.nextLine();
			if ("-".equals(methodName)) {
				break;
			}
			try {
				Method method = clazz.getMethod(methodName, new Class[0]);
				method.invoke(instance, new Object[0]);
			} catch (Throwable e) {
				e.printStackTrace();
			} 
		}

	}

}
