package com.webagesolutions.i18n;

import java.text.Format;
import java.text.NumberFormat;
import java.util.Locale;

public class CurrencyFormats {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		Locale america=Locale.US;
		Locale england=Locale.UK;
		Locale here=Locale.getDefault();

		double value=1276.92; 

		Format americanCurrency=NumberFormat.getCurrencyInstance(america);
		Format englishCurrency=NumberFormat.getCurrencyInstance(england);
		Format localCurrency=NumberFormat.getCurrencyInstance(here);

		System.out.format("American value is %s\n", americanCurrency.format(value));
		System.out.format("English value is %s\n", englishCurrency.format(value));
		System.out.format("Local value is %s\n", localCurrency.format(value));



	}

}
