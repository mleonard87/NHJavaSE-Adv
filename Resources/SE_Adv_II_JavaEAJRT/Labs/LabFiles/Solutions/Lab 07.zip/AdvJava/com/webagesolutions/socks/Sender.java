package com.webagesolutions.socks;

import java.io.DataOutputStream;
import java.net.Socket;
import java.util.Scanner;

public class Sender {
	public static void main(String[] args) {
		Socket socket = null;

		System.out.println("Opening a socket.");
		try {
			socket = new Socket("localhost", 10001);
			Scanner consoleScanner = new Scanner(System.in);
			Scanner inputScanner = new Scanner(socket.getInputStream());
			DataOutputStream netOutput = new DataOutputStream(socket
					.getOutputStream());
			while (true) {
				String s = consoleScanner.nextLine();
				System.out.printf("Input: %s\n", s);
				netOutput.writeBytes(s + "\n");
				;
				netOutput.flush();
				String response = inputScanner.nextLine();
				System.out.printf("Response: %s\n", response);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			try {
				socket.close();
			} catch (Throwable t) {
			}
			System.exit(0);
		}
	}

}
