package com.webagesolutions.socks;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class Responder {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ServerSocket serverSocket;
		Executor threadPool;

		try {
			threadPool = Executors.newCachedThreadPool();
			serverSocket = new ServerSocket(10001);
			
			System.out.print("Responder Awaiting Connections");

			while (true) {
				Socket s = serverSocket.accept();
				System.out.printf("Got a connection from %s\n",
						s.getRemoteSocketAddress());

				ResponderHandler handler = new ResponderHandler(s);
				threadPool.execute(handler);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
