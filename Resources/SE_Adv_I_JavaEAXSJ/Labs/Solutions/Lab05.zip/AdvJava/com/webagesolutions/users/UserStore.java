
package com.webagesolutions.users;

public interface UserStore {
	public void putUser(User aUser, String verifyPassword) throws UserAddException ;

	public Iterable<User> listAllUsers();
	
	public User getUser(String email);
}
