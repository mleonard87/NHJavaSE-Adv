package com.webagesolutions.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;

import com.webagesolutions.users.DBUtils;
import com.webagesolutions.users.User;
import com.webagesolutions.users.UserAddException;
import com.webagesolutions.users.UserStore;

public class DBUserStore implements UserStore {
	private Connection connection;

	public DBUserStore(Connection conn) {
		connection = conn;
	}

	@Override
	public void putUser(User aUser, String verifyPassword)
			throws UserAddException {
		if (verifyPassword.equals(aUser.getPassword())) {
			try {
				DBUtils.writeUser(connection, aUser);
			} catch (SQLException e) {
				e.printStackTrace();
				throw new UserAddException(e);
			}
		} else {
			throw new UserAddException("Password incorrect.");
		}
	}

	@Override
	public Iterable<User> listAllUsers() {
		return new Iterable<User>() {
			public Iterator<User> iterator() {
				return new ListAllIterator();
			}
		};
	}

	@Override
	public User getUser(String email) {
		PreparedStatement st = null;
		String query = "SELECT * from USERS where EMAIL=?";
		try {
			st = connection.prepareStatement(query);
			st.setString(1, email);
			ResultSet rs = st.executeQuery();
			if (rs.next()) {
				return DBUtils.readUser(rs);
			} else {
				return null;
			}
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		} finally {
			if (st != null) {
				try {
					st.close();
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		}
	}

	private class ListAllIterator implements Iterator<User> {
		Statement st = null;
		ResultSet rs = null;
		User nextResult = null;

		ListAllIterator() {
			/* Perform the query, storing the resultset in this instance. */
			try {
				st = connection.createStatement();
				rs = st.executeQuery("SELECT * FROM USERS");
				advance();
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}

		public boolean hasNext() {
			/* Return true if there is a next result available. */
			return (nextResult != null);
		}

		public User next() {
			/*
			 * Return the current 'next' result and try to navigate to the
			 * 'next' next result.
			 */
			User currentNext = nextResult;
			advance();
			return currentNext;
		}

		public void remove() {
			throw new UnsupportedOperationException();
		}

		private void advance() {
			try {
				if (st == null) {
					/* Already at end, so just return. */
					return;
				}
				if (rs.next()) {
					/* There is a next result; instantiate it. */
					nextResult = DBUtils.readUser(rs);
				} else {
					/* We're at the end, so close the result set and statement. */
					nextResult = null;
					try {
						st.close();
					} catch (Exception e) {
					}
					rs = null;
					st = null;
				}
			} catch (SQLException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}
	}

}
