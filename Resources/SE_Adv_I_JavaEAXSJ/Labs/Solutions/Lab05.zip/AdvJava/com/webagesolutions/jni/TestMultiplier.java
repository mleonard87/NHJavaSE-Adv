package com.webagesolutions.jni;

public class TestMultiplier {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		int result = Multiplier.multiply(40, -22);
		System.out.printf("Result was %d\n", result);

	}

}
