package com.webagesolutions.i18n;

import java.util.Locale;
import java.util.ResourceBundle;

public class LocalizedMessages {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		String rbName = "com.webagesolutions.i18n.messages";
		ResourceBundle germany = ResourceBundle.getBundle(rbName,
				Locale.GERMANY);
		ResourceBundle france = ResourceBundle.getBundle(rbName, Locale.FRANCE);
		ResourceBundle england = ResourceBundle.getBundle(rbName, Locale.UK);
		ResourceBundle here = ResourceBundle.getBundle(rbName);

		System.out.println(germany.getString("msg.welcome"));
		System.out.println(france.getString("msg.welcome"));
		System.out.println(england.getString("msg.welcome"));
		System.out.printf("Default locale is '%s': ", Locale.getDefault());
		System.out.println(here.getString("msg.welcome"));
	}

}
