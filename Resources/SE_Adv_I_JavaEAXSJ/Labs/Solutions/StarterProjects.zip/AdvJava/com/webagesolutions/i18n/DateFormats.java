package com.webagesolutions.i18n;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Scanner;

public class DateFormats {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		DateFormat usShort = DateFormat.getDateInstance(DateFormat.SHORT,
				Locale.US);
		DateFormat germanLong = DateFormat.getDateInstance(DateFormat.LONG,
				Locale.GERMANY);
		DateFormat defaultMedium = DateFormat
				.getDateInstance(DateFormat.MEDIUM);
		DateFormat custom = new SimpleDateFormat("yyyyMMdd HH:mm:ss");

		Scanner in = new Scanner(System.in);
		Date now = new Date();
		System.out.format("Enter a date in the local format: %s\n",
				defaultMedium.format(now));
		String input = in.nextLine();

		Date dt = null;
		try {
			dt = defaultMedium.parse(input);
		} catch (ParseException e) {
			System.out.println("Didn't understand the date; using 'now'");
			dt = now;
		}

		System.out.format("US Short: %s\n", usShort.format(dt));
		System.out.format("German Long: %s\n", germanLong.format(dt));
		System.out.format("Default Locale medium: %s\n",
				defaultMedium.format(dt));
		System.out.format("Custom: %s\n", custom.format(dt));
	}

}
