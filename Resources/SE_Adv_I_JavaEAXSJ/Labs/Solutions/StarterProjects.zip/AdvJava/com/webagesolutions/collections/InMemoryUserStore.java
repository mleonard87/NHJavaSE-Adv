package com.webagesolutions.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.webagesolutions.users.User;
import com.webagesolutions.users.UserAddException;
import com.webagesolutions.users.UserStore;

public class InMemoryUserStore implements UserStore {
	
	private List<User> userList = new ArrayList<User>();
	private Map<String, User> index = new HashMap<String, User>();

	@Override
	public void putUser(User aUser, String verifyPassword)
			throws UserAddException {
		if (verifyPassword.equals(aUser.getPassword())) {
			userList.add(aUser);
			index.put(aUser.getEmail(), aUser);
		} else {
			throw new UserAddException("Password incorrect.");
		}
	}

	@Override
	public Iterable<User> listAllUsers() {
		return Collections.unmodifiableList(userList);
	}

	@Override
	public User getUser(String email) {
		return index.get(email);
	}

}
