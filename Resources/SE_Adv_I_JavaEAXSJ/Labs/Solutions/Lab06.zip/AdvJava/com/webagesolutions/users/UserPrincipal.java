package com.webagesolutions.users;

import java.security.Principal;

public class UserPrincipal implements Principal {

	String name=null;
	
	public UserPrincipal(String name) {
		this.name=name;
	}
	
	public String getName() {
		return name;
	}

	public String toString() {
		return "UserStore user '" + getName() + "'";
	}
}
