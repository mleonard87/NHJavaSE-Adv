package com.webagesolutions.users;


	public class UserAddException extends Exception {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public UserAddException() {
			super();
		}

		public UserAddException(String arg0) {
			super(arg0);
		}

		public UserAddException(String arg0, Throwable arg1) {
			super(arg0, arg1);
		}

		public UserAddException(Throwable arg0) {
			super(arg0);
		}

	}
